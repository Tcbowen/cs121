package com.ucsc.jeremy.backendtest1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;

public class SendActivity extends AppCompatActivity {

    RequestQueue queue;
    private final String LOG_TAG = "backendstuff";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);

        queue = Volley.newRequestQueue(this);

        final EditText sender = findViewById(R.id.sendText);
        final EditText recipient = findViewById(R.id.receiveText);
        final EditText message = findViewById(R.id.msgText);
        Button b = findViewById(R.id.submitText);

        b.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                String senderText = sender.getText().toString();
                String receiverText = recipient.getText().toString();
                String messageText = message.getText().toString();

                sendMsg(senderText, receiverText, messageText);

                //pop the activity off the stack
                Intent i = new Intent(SendActivity.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });

    }

    private void sendMsg(final String sender, final String recipient, final String msg) {

        StringRequest sr = new StringRequest(Request.Method.POST,
                "https://bathroom-map-1525993289750.appspot.com/backend/api_w_ndb/send_msg",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(LOG_TAG, "Got:" + response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("sender", sender);
                params.put("recipient" , recipient);
                params.put("msg", msg);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(sr);

    }
}
