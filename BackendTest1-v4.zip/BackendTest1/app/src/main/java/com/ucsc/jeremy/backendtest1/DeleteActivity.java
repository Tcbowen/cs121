package com.ucsc.jeremy.backendtest1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

public class DeleteActivity extends AppCompatActivity {

    RequestQueue queue;
    //RequestQueue queue2;
    private final String LOG_TAG = "backendstuff";
    TextView m;
    EditText receiver;
    EditText sender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        queue = Volley.newRequestQueue(this);

        Button bView = findViewById(R.id.button3);
        Button bDel = findViewById(R.id.button4);
        //final TextView m = (TextView)findViewById(R.id.msgHistory);
        final EditText receiver = findViewById(R.id.recDel);
        final EditText sender = findViewById(R.id.sendDel);
        final TextView m = (TextView)findViewById(R.id.delHistory);


        bView.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){

                String receiverText = receiver.getText().toString();
                String senderText = sender.getText().toString();
                getMessages(senderText, receiverText);
                //m.setText(queue.)

                //pop the activity off the stack
                //Intent i = new Intent(ViewActivity.this, MainActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                //startActivity(i);
            }
        });

        bDel.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){

                String receiverText = receiver.getText().toString();
                String senderText = sender.getText().toString();
                deleteMessages(senderText, receiverText);
                //m.setText(queue.)

                //pop the activity off the stack
                //Intent i = new Intent(ViewActivity.this, MainActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                //startActivity(i);
            }
        });

    }

    private void getMessages(final String sender, final String recipient) {

        //queue2 = Volley.newRequestQueue(this);
        final TextView m = (TextView)findViewById(R.id.delHistory);

        // Instantiate the RequestQueue.
        String url = "https://bathroom-map-1525993289750.appspot.com/backend/api_w_ndb/get_msg_thread";

        String valueS = "";
        String valueR = "";

        try {
            valueR = URLEncoder.encode(recipient, "UTF-8");
            valueS = URLEncoder.encode(sender, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new AssertionError("UTF-8 is unknown");
        }

        String my_url = url + "?recipient=" + valueR + "&sender=" + valueS;

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.GET, my_url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            /*
                            JSONArray receivedList = response.getJSONArray("mylist");
                            String allTogether = "(";
                            for (int i = 0; i < receivedList.length(); i++) {
                                allTogether += receivedList.getString(i) + ";";
                            }
                            allTogether += ")";
                            m.setText(allTogether);*/
                            m.setText(response.toString());
                        } catch (Exception e) {
                            m.setText("Aaauuugh, received bad json: " + e.getStackTrace());
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d(LOG_TAG, error.toString());
                    }
                });

        // In some cases, we don't want to cache the request.
        // jsObjRequest.setShouldCache(false);

        queue.add(jsObjRequest);
    }


    private void deleteMessages(final String sender, final String recipient) {

        //queue2 = Volley.newRequestQueue(this);
        final TextView m = (TextView)findViewById(R.id.delHistory);

        // Instantiate the RequestQueue.
        String url = "https://bathroom-map-1525993289750.appspot.com/backend/api_w_ndb/delete_msg";

        String valueS = "";
        String valueR = "";

        try {
            valueR = URLEncoder.encode(recipient, "UTF-8");
            valueS = URLEncoder.encode(sender, "UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new AssertionError("UTF-8 is unknown");
        }

        String my_url = url + "?recipient=" + valueR + "&sender=" + valueS;

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.GET, my_url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            /*
                            JSONArray receivedList = response.getJSONArray("mylist");
                            String allTogether = "(";
                            for (int i = 0; i < receivedList.length(); i++) {
                                allTogether += receivedList.getString(i) + ";";
                            }
                            allTogether += ")";
                            m.setText(allTogether);*/
                            m.setText(response.toString());
                        } catch (Exception e) {
                            m.setText("Aaauuugh, received bad json: " + e.getStackTrace());
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d(LOG_TAG, error.toString());
                    }
                });

        // In some cases, we don't want to cache the request.
        // jsObjRequest.setShouldCache(false);

        queue.add(jsObjRequest);
    }

}
