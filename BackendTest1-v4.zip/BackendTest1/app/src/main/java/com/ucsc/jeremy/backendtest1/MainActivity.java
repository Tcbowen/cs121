package com.ucsc.jeremy.backendtest1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;

/*
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
*/

public class MainActivity extends AppCompatActivity {

    private final String LOG_TAG = "backendstuff";

    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        queue = Volley.newRequestQueue(this);

        Button b1 = findViewById(R.id.sendMsg);
        b1.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //getList();
                //sendMsg("User1", "User2", "This is another test.");
                //getMessages("mario");
                Intent i1 = new Intent(MainActivity.this, SendActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);
            }
        });
        Button b2 = findViewById(R.id.viewMsg);
        b2.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //getList();
                //sendMsg("User1", "User2", "This is another test.");
                //getMessages("mario");
                Intent i2 = new Intent(MainActivity.this, ViewActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i2);
            }
        });
        Button b3 = findViewById(R.id.delMsg);
        b3.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                //getList();
                //sendMsg("User1", "User2", "This is another test.");
                //getMessages("mario");
                Intent i3 = new Intent(MainActivity.this, DeleteActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i3);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        // We need the "final" keyword here to guarantee that the
        // value does not change, as it is used in the callbacks.

        //getList();
        //sendMsg("Anna", "Clara", "This is a test.");
        //getMessages("mario");
    }

    private void getList() {
        final TextView mTextView = (TextView) findViewById(R.id.textView1);
        final TextView detailView = (TextView) findViewById(R.id.textView2);

        // Instantiate the RequestQueue.
        String url = "https://bathroom-map-1525993289750.appspot.com/backend/api/get_list";

        JsonObjectRequest jsObjRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        mTextView.setText("Response json: " + response.toString());
                        Log.d(LOG_TAG, "Received: " + response.toString());
                        // Ok, let's disassemble a bit the json object.
                        try {
                            JSONArray receivedList = response.getJSONArray("mylist");
                            String allTogether = "(";
                            for (int i = 0; i < receivedList.length(); i++) {
                                allTogether += receivedList.getString(i) + ";";
                            }
                            allTogether += ")";
                            detailView.setText(allTogether);
                        } catch (Exception e) {
                            mTextView.setText("Aaauuugh, received bad json: " + e.getStackTrace());
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d(LOG_TAG, error.toString());
                    }
                });

        // In some cases, we don't want to cache the request.
        // jsObjRequest.setShouldCache(false);

        queue.add(jsObjRequest);
    }

}
