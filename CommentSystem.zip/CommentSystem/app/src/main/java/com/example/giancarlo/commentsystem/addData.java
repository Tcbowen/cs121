package com.example.giancarlo.commentsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class addData extends AppCompatActivity {
    JSONObject jo;
    JSONArray ja;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        final EditText login = findViewById(R.id.editText);
        final EditText comment = findViewById(R.id.editText2);
        Button b = findViewById(R.id.enterButton);

        try {
            File f = new File(getFilesDir(), "file.ser");
            FileInputStream fi = new FileInputStream(f);
            ObjectInputStream o = new ObjectInputStream(fi);
            String j = null;
            try {
                j = (String)o.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                jo = new JSONObject(j);
                ja = jo.getJSONArray("data");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            jo = new JSONObject();
            ja = new JSONArray();
            try {
                jo.put("data", ja);
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }

        b.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){
                String Login = login.getText().toString();
                String Comment = comment.getText().toString();

                JSONObject temp =new JSONObject();

                try {
                    temp.put("login",Login);
                    temp.put("comment", Comment);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ja.put(temp);

                try {
                    File f = new File(getFilesDir(), "file.ser");
                    FileOutputStream fo = new FileOutputStream(f);
                    ObjectOutputStream o = new ObjectOutputStream(fo);
                    String j = jo.toString();
                    o.writeObject(j);
                    o.close();
                    fo.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Intent i = new Intent(addData.this, commentList.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });
    }
}
