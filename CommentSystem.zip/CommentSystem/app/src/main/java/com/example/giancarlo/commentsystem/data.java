package com.example.giancarlo.commentsystem;

public class data {
    public String login;
    public int rating;
    public String comment;
    //public String date;

}
