package com.example.giancarlo.commentsystem;


import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class commentList extends AppCompatActivity {

    JSONObject jo;
    JSONArray ja;
    private ListView mlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_list);

        //List<String> commentTest = new ArrayList<>(Arrays.asList("Great bathroom, really clean!", "Wow great place, much clean", "My experience was sub-par as the restroom ran out of toilet paper",
       //         "space", "helpful comment", "P", "stuff", "more stuff", "!!!", "bathroom talk", "fart joke", "room clean", "end"));
       // itemAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, commentTest);

        mlist = (ListView) findViewById(R.id.test);
        //list.setAdapter(itemAdapter);


        jo = null;
        ja = null;

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(commentList.this, addData.class);
                startActivity(i);
            }
        });

    }

    protected void onResume(){
        super.onResume();
        Log.d("test", "onResume entered");
        TextView msg = findViewById(R.id.textView);
        msg.setVisibility(View.INVISIBLE);

        try {
            File f = new File(getFilesDir(), "file.ser");
            FileInputStream fi = new FileInputStream(f);
            ObjectInputStream o = new ObjectInputStream(fi);
            String j = null;

            try {
                j = (String) o.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            try {
                jo = new JSONObject(j);
                ja = jo.getJSONArray("data");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            final ArrayList<data> list = new ArrayList<data>();

            for(int i = 0; i < ja.length(); i++){
                data ld = new data();
                try {
                    ld.comment = ja.getJSONObject(i).getString("comment");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                list.add(ld);
            }

            String[] listItems = new String[list.size()];

            for(int i = 0; i < list.size(); i++){
                data listD = list.get(i);
                listItems[i] = listD.comment;
            }

            ArrayAdapter adapter  = new ArrayAdapter(this,android.R.layout.simple_list_item_1, listItems);
            mlist.setAdapter(adapter);


        } catch (IOException e) {
            mlist.setEnabled(false);
            mlist.setVisibility(View.INVISIBLE);

            msg.setVisibility(View.VISIBLE);
        }
    }
}
