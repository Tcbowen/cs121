package com.example.giancarlo.commentsystem;


import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class commentList extends AppCompatActivity {
    ArrayAdapter<String> itemAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_list);
        List<String> commentTest = new ArrayList<>(Arrays.asList("Great bathroom, really clean!", "Wow great place, much clean", "My experience was sub-par as the restroom ran out of toilet paper",
                "space", "helpful comment", "P", "stuff", "more stuff", "!!!", "bathroom talk", "fart joke", "room clean", "end"));
        itemAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, commentTest);

        ListView list = (ListView) findViewById(R.id.test);
        list.setAdapter(itemAdapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Load the add Comment activity here", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }
}
