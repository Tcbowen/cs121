package com.example.jacem_000.bathroommap;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    private GoogleMap mMap;
    private GoogleApiClient client;
    private LocationRequest locationRequest;
    private Location lastLocation;
    private Marker currentLocationMarker;
    private Marker mBaskin;
    private Marker mBaskin2;
    public static final int REQUEST_LOCATION_CODE = 99;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            checkLocationPermission();
        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case REQUEST_LOCATION_CODE:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //permission granted
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        if (client == null) {
                            buildGoogleApiClient();
                        }
                        mMap.setMyLocationEnabled(true);
                    }
                } else{
                    Toast.makeText(this, "Permission Denied" , Toast.LENGTH_LONG).show();
                }
                return;
        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

        LatLng baskin = new LatLng(37.000151, -122.063089);
        googleMap.addMarker(new MarkerOptions()
                .position(baskin)
                .title("Bathroom in Baskin"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(baskin));

        LatLng baskin2 = new LatLng(37.000883, -122.063114);
        googleMap.addMarker(new MarkerOptions()
                .position(baskin2)
                .title("Bathroom in Engineering 2"));

        LatLng pbsci = new LatLng(36.999606, -122.062027);
        googleMap.addMarker(new MarkerOptions()
                .position(pbsci)
                .title("Bathroom in PB Sci"));

        LatLng film = new LatLng(37.000848, -122.061421);
        googleMap.addMarker(new MarkerOptions()
                .position(film)
                .title("Bathroom in Communications"));

        LatLng reclounge = new LatLng(37.000587, -122.057673);
        googleMap.addMarker(new MarkerOptions()
                .position(reclounge)
                .title("Bathroom in 9/10 Rec Lounge"));

        LatLng ss2 = new LatLng(37.001529, -122.058749);
        googleMap.addMarker(new MarkerOptions()
                .position(ss2)
                .title("Bathroom in Social Sciences 2"));

        LatLng ss1 = new LatLng(37.001884, -122.057891);
        googleMap.addMarker(new MarkerOptions()
                .position(ss1)
                .title("Bathroom in Social Sciences 1"));


        LatLng dh910 = new LatLng(37.000732, -122.057773);
        googleMap.addMarker(new MarkerOptions()
                .position(dh910)
                .title("Bathroom in 9/10 Dining Hall"));

        LatLng crown = new LatLng(37.000036, -122.054805);
        googleMap.addMarker(new MarkerOptions()
                .position(crown)
                .title("Bathroom in Crown Classrooms"));

        LatLng crown2 = new LatLng(36.999834, -122.054459);
        googleMap.addMarker(new MarkerOptions()
                .position(crown2)
                .title("Bathroom in Crown Offices"));

        LatLng crowndh = new LatLng(367.000124, -122.054409);
        googleMap.addMarker(new MarkerOptions()
                .position(crowndh)
                .title("Bathroom in Crown/Merrill Dining Hall"));


        LatLng merrill = new LatLng(36.999687, -122.053587);
        googleMap.addMarker(new MarkerOptions()
                .position(merrill)
                .title("Bathroom in Merrill Classrooms"));

        LatLng cc = new LatLng(37.000228, -122.053809);
        googleMap.addMarker(new MarkerOptions()
                .position(cc)
                .title("Bathroom near Merrill Cultural Center"));

        LatLng stevenson = new LatLng(36.997141, -122.051843);
        googleMap.addMarker(new MarkerOptions()
                .position(stevenson)
                .title("Bathroom in Stevenson Classrooms"));


        LatLng cowell = new LatLng(36.997229, -122.053017);
        googleMap.addMarker(new MarkerOptions()
                .position(cowell)
                .title("Bathroom near Cowell Programs Office"));

        LatLng cowell2 = new LatLng(36.997084, -122.052886);
        googleMap.addMarker(new MarkerOptions()
                .position(cowell2)
                .title("Bathroom near Cowell/Stevenson Dining Hall"));

        LatLng cowell3 = new LatLng(36.99726, -122.053486);
        googleMap.addMarker(new MarkerOptions()
                .position(cowell3)
                .title("Bathroom in Cowell Administrative Building"));

        LatLng humanities = new LatLng(36.999606, -122.062027);
        googleMap.addMarker(new MarkerOptions()
                .position(humanities)
                .title("Bathroom near Humanities Lecture Hall"));

        LatLng quarry = new LatLng(36.998251, -122.055531);
        googleMap.addMarker(new MarkerOptions()
                .position(quarry)
                .title("Bathroom in Quarry Plaza"));

        LatLng careercenter = new LatLng(36.99775, -122.05552);
        googleMap.addMarker(new MarkerOptions()
                .position(careercenter)
                .title("Bathroom near Career Center"));

        LatLng opers = new LatLng(36.995047, -122.054012);
        googleMap.addMarker(new MarkerOptions()
                .position(opers)
                .title("Bathroom/Locker Room in OPERS"));

        LatLng opers2 = new LatLng(36.994575, -122.05486);
        googleMap.addMarker(new MarkerOptions()
                .position(opers2)
                .title("Bathroom/Locker Room in OPERS"));

        LatLng mchenry = new LatLng(36.995561, -122.058883);
        googleMap.addMarker(new MarkerOptions()
                .position(mchenry)
                .title("Bathroom on each floor of McHenry Library"));

        LatLng arc = new LatLng(36.994349, -122.059296);
        googleMap.addMarker(new MarkerOptions()
                .position(arc)
                .title("Bathroom in ARCenter"));

        LatLng oakes = new LatLng(36.989618, -122.062799);
        googleMap.addMarker(new MarkerOptions()
                .position(oakes)
                .title("Bathroom in Oakes Academic Building"));

        LatLng porter = new LatLng(36.993911, -122.065407);
        googleMap.addMarker(new MarkerOptions()
                .position(porter)
                .title("Bathroom in Porter Academic Building"));

        LatLng thimann = new LatLng(36.998153, -122.061689);
        googleMap.addMarker(new MarkerOptions()
                .position(thimann)
                .title("Bathroom in Thimann Labs"));

        LatLng thimann2 = new LatLng(36.998037, -122.061319);
        googleMap.addMarker(new MarkerOptions()
                .position(thimann2)
                .title("Bathroom next to Thimann Lecture Halls"));

        LatLng cookhouse = new LatLng(36.978906, -122.0545);
        googleMap.addMarker(new MarkerOptions()
                .position(cookhouse)
                .title("Bathroom in Cookhouse"));

        LatLng kresgeth = new LatLng(36.998747, -122.066217);
        googleMap.addMarker(new MarkerOptions()
                .position(kresgeth)
                .title("Bathroom in Kresge Town Hall"));

        LatLng kresgewc = new LatLng(36.997903, -122.065540);
        googleMap.addMarker(new MarkerOptions()
                .position(kresgewc)
                .title("Bathroom in Kresge Writing Center"));

        LatLng mediac = new LatLng(36.9948056,-122.0621052);
        googleMap.addMarker(new MarkerOptions()
                .position(mediac)
                .title("Bathroom in Media Theater"));

        LatLng redroom = new LatLng(36.991244, -122.064791);
        googleMap.addMarker(new MarkerOptions()
                .position(redroom)
                .title("Bathroom in the Red Room"));

        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                android.content.Intent i = new Intent(MapsActivity.this, info.class);
                startActivity(i);
                return false;
            }
        });


    }

    protected synchronized void buildGoogleApiClient() {
        client = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        client.connect();
    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;

        if(currentLocationMarker != null){
            currentLocationMarker.remove();
        }

        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Current Location");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));

        currentLocationMarker = mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomBy(20));

        if(client != null){
            LocationServices.FusedLocationApi.removeLocationUpdates(client, this);
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();

        locationRequest.setInterval(20);
        locationRequest.setFastestInterval(20);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(client, locationRequest, this);
        }
    }

    public boolean checkLocationPermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)){
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            }
            return false;
        } else{
            return true;
        }
    }





    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
