package com.ucsc.jeremy.backendtest2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import static android.webkit.ConsoleMessage.MessageLevel.LOG;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //queue = Volley.newRequestQueue(this);

        Button b1 = findViewById(R.id.readB);
        b1.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent i1 = new Intent(MainActivity.this, MapsMarkerActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i1);
            }
        });
        Button b2 = findViewById(R.id.editB);
        b2.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent i2 = new Intent(MainActivity.this, EditActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i2);
            }
        });
        Button b3 = findViewById(R.id.loginB);
        b3.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent i3 = new Intent(MainActivity.this, LoginActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i3);
            }
        });
        Button b4 = findViewById(R.id.logoutB);
        b4.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                Intent i4 = new Intent(MainActivity.this, LogoutActivity.class);
                //i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i4);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();

        // We need the "final" keyword here to guarantee that the
        // value does not change, as it is used in the callbacks.

        //getList();
        //sendMsg("Anna", "Clara", "This is a test.");
        //getMessages("mario");
    }

}
