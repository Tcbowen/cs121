package com.ucsc.jeremy.backendtest2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EditActivity extends AppCompatActivity {

    RequestQueue queue;
    private final String LOG_TAG = "backendstuff";
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        queue = Volley.newRequestQueue(this);
        final Button b = findViewById(R.id.sendB);

        SharedPreferences prefs = this.getSharedPreferences("SHARED_PREFERENCES", 0);
        if (!prefs.contains("ID_TOKEN")) {
            Toast.makeText(this, "You must sign in to do that.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(EditActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } else {
            final String userKey = prefs.getString("ID_TOKEN", "Error: Sign in");

            final EditText e = findViewById(R.id.sendText);

            b.setOnClickListener(new Button.OnClickListener(){
                public void onClick(View v){
                    final String jsonText = e.getText().toString();

                    sendContent(userKey, jsonText);

                    //pop the activity off the stack
                    Intent i = new Intent(EditActivity.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(i);
                }
            });
        }
    }

    private void sendContent(final String userKey, final String jsonText) {

        queue = Volley.newRequestQueue(this);

        StringRequest sr = new StringRequest(Request.Method.POST,
                "https://bathroom-map-1525993289750.appspot.com/backend/api/send_json",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(LOG_TAG, "Got:" + response);
                        try {
                            /*
                            JSONArray receivedList = response.getJSONArray("mylist");
                            String allTogether = "(";
                            for (int i = 0; i < receivedList.length(); i++) {
                                allTogether += receivedList.getString(i) + ";";
                            }
                            allTogether += ")";
                            m.setText(allTogether);*/
                            //c.setText(response.toString());
                        } catch (Exception e) {
                            //c.setText("Error - received bad json: " + e.getStackTrace());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", userKey);
                params.put("content", jsonText);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(sr);

    }
}
