package com.example.tomb3.tag;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class search extends AppCompatActivity {

    JSONObject jos = null;
    JSONArray Jarr = null;
    int k = 0;
    ArrayList<String> output;
    String key;
    TextView out;
    EditText sBar;
    int numBath =2;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        out = (TextView) findViewById(R.id.output);
        sBar = findViewById(R.id.input);
    }

    public void Search(View view) {
        int count = 1;
        String bathroomName = "bathroom";
        output = new ArrayList<String>(10);
        File JD = null;
        key = sBar.getText().toString();
            do {
                boolean add = false;
                try{
                    JD = new File(getFilesDir(), bathroomName + count + ".ser");
                    Log.d("bathroomName", bathroomName + count + ".ser");
                    FileInputStream fi = new FileInputStream(JD);
                    ObjectInputStream o = new ObjectInputStream(fi);
                    String j = null;
                    try {
                        j = (String) o.readObject();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    jos = new JSONObject(j);
                    Jarr = jos.getJSONArray("data");
                //load Jason data
                try {
                    for (int i = 0; i < Jarr.length(); i++) {
                        try {
                            if (Jarr.getJSONObject(i).getString("tag").equals(key)) {
                                add = true;
                                k++;
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                    if (add){
                        output.add(bathroomName+count);
                    }
                // incrimetn the bathroom number..
            } catch (Exception e) {
                    e.printStackTrace();
                    Log.d("bathroomName", "File is NULL");
            }
                count++;
        } while (count <= numBath);
            Log.d("out", "should print");
            out.setText(output.toString());
    }
}
