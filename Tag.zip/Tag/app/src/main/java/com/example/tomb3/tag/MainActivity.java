package com.example.tomb3.tag;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    //@Override
    EditText tag;
    TextView display;
    JSONObject jos = null;
    JSONArray Jarr = null;
    String bathroomName;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tag = (EditText) findViewById(R.id.tags);
        display = (TextView) findViewById(R.id.display);
        Bundle extras = getIntent().getExtras();
        bathroomName = extras.getString("bathroomName");
        try {
            File JD = new File(getFilesDir(), bathroomName+".ser");
            Log.d("bathroomName", bathroomName);
            FileInputStream fi = new FileInputStream(JD);
            ObjectInputStream o = new ObjectInputStream(fi);
            String j = null;
            try {
                j = (String) o.readObject();
            } catch (Exception e) {
                e.printStackTrace();
            }
                jos = new JSONObject(j);
                Jarr = jos.getJSONArray("data");
            Log.d("bathroomName", "loaded");
            } catch (Exception e) {
                jos = new JSONObject();
                Jarr = new JSONArray();
                try {
                    jos.put("data", Jarr);
                    try{
                        File data = new File(getFilesDir(),bathroomName+".ser");
                        FileOutputStream fi = new FileOutputStream(data);
                        ObjectOutputStream o = new ObjectOutputStream(fi);
                        String j = jos.toString();
                        o.writeObject(j);
                        o.close();
                        fi.close();
                    } catch (Exception e2) {
                        e.printStackTrace();
                    }
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            }
        String[] data = null;
        try {
            data = new String[Jarr.length()];
            for (int i = 0; i < Jarr.length(); i++) {
                try {
                    data[i] = Jarr.getJSONObject(i).getString("tag");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            display.setText(Arrays.toString(data));
        }catch(Exception e) {
            Log.d("print","fail");
            e.printStackTrace();
        }
    }
        public void add(View view) {
        JSONObject temp = new JSONObject();
        try {
            temp.put("tag", tag.getText().toString());
            Jarr.put(temp);
            Log.d("added",tag.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tag.setText("");
    }

    public void Back(View view) {
        try {
            File data = new File(getFilesDir(),bathroomName+".ser");
            FileOutputStream fi = new FileOutputStream(data);
            ObjectOutputStream o = new ObjectOutputStream(fi);
            String j = jos.toString();
            o.writeObject(j);
            Log.d("added","added");
        } catch (Exception e) {
            Log.d("added","fail");
            e.printStackTrace();
        }
        Intent intent = new Intent(MainActivity.this, MapsActivity.class);
        startActivity(intent);
    }
    public void search(View view){
        Intent intent = new Intent(MainActivity.this, search.class);
        startActivity(intent);
    }
}