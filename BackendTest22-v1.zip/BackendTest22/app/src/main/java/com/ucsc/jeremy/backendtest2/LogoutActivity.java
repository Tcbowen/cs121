package com.ucsc.jeremy.backendtest2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class LogoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);

        SharedPreferences prefs = this.getSharedPreferences("SHARED_PREFERENCES", 0);
        if(prefs.contains("ID_TOKEN")){
            WebView logout = (WebView) findViewById(R.id.logoutView);
            logout.setWebViewClient(new WebViewClient());
            logout.loadUrl("https://bathroom-map-1525993289750.appspot.com/backend/users/logout");

            SharedPreferences.Editor editor = prefs.edit();
            editor.remove("ID_TOKEN");
            editor.commit();

            Toast.makeText(this, "Signed out.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(LogoutActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } else {
            Toast.makeText(this, "You are not signed in.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(LogoutActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }

    }
}
