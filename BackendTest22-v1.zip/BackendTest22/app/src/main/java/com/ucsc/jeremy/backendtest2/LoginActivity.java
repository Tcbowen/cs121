package com.ucsc.jeremy.backendtest2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        SharedPreferences prefs = this.getSharedPreferences("SHARED_PREFERENCES", 0);
        if(prefs.contains("ID_TOKEN")){
            Toast.makeText(this, "You are already signed in.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } else {
            WebView login = (WebView) findViewById(R.id.loginPage);
            WebSettings ws = login.getSettings();
            ws.setJavaScriptEnabled(true);
            login.addJavascriptInterface(new JavaScriptInterface(this), "Android");
            login.setWebViewClient(new WebViewClient());
            login.loadUrl("https://bathroom-map-1525993289750.appspot.com/backend/users/login");
        }

    }

    public class JavaScriptInterface {
        Context mContext;


        JavaScriptInterface(Context c){
            mContext = c;
        }

        @JavascriptInterface
        public void loginToken(String userToken){
            SharedPreferences prefs = mContext.getSharedPreferences("SHARED_PREFERENCES", 0);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("ID_TOKEN", userToken);
            editor.commit();
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        }
    }

}
