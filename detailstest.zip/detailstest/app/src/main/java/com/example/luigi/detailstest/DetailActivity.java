package com.example.luigi.detailstest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {
    String userName = "tom";
    JSONObject jo;
    JSONArray Bathrooms;
    JSONArray ja;
    int brNum = 0;
    double rating;
    int tag1;
    int tag2;
    int tag3;
    int tag4;
    int tag5;
    int tag6;
    private ListView mlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mlist = (ListView) findViewById(R.id.CommentList);

        jo = null;
        ja = null;


    }

    protected void onResume(){
        super.onResume();
        Log.d("test", "onResume entered");
        TextView msg = findViewById(R.id.emptyList);
        msg.setVisibility(View.INVISIBLE);

        try {
            File f = new File(getFilesDir(), userName + ".ser");
            FileInputStream fi = new FileInputStream(f);
            ObjectInputStream o = new ObjectInputStream(fi);
            String j = null;

            try {
                j = (String) o.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            try {
                jo = new JSONObject(j);
                Bathrooms = jo.getJSONArray("bathrooms");
            } catch (JSONException e) {
                jo = new JSONObject();
                Bathrooms = new JSONArray();
                try {
                    jo.put("bathrooms", Bathrooms);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            }
            try {
                ja = Bathrooms.getJSONArray(brNum);
            } catch (JSONException e) {
                e.printStackTrace();

                ja = new JSONArray();
            }


            final ArrayList<data> list = new ArrayList<data>();

            for(int i = 0; i < ja.length(); i++){
                data ld = new data();
                try {
                    ld.comment = ja.getJSONObject(i).getString("comment");
                    ld.rating = ja.getJSONObject(i).getDouble("rating");
                    ld.tag1 = ja.getJSONObject(i).getInt("tag1");
                    ld.tag2 = ja.getJSONObject(i).getInt("tag2");
                    ld.tag3 = ja.getJSONObject(i).getInt("tag3");
                    ld.tag4 = ja.getJSONObject(i).getInt("tag4");
                    ld.tag5 = ja.getJSONObject(i).getInt("tag5");
                    ld.tag6 = ja.getJSONObject(i).getInt("tag6");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                list.add(ld);
            }

            String[] listItems = new String[list.size()];
            rating = 0;
            tag1 = 0;
            tag2 = 0;
            tag3 = 0;
            tag4 = 0;
            tag5 = 0;
            tag6 = 0;

            for(int i = 0; i < list.size(); i++){
                data listD = list.get(i);
                listItems[i] = listD.comment;
                rating += listD.rating;
                tag1 += listD.tag1;
                tag2 += listD.tag2;
                tag3 += listD.tag3;
                tag4 += listD.tag4;
                tag5 += listD.tag5;
                tag6 += listD.tag6;
            }
            Log.d("test", "Rating: " + rating + "tag1: " + tag1);


            RatingBar rb = findViewById(R.id.ratingBar);
            rating /= list.size();
            rb.setRating((float)rating);

            TextView t1 = findViewById(R.id.Tag1_value);
            t1.setText(Integer.toString(tag1));
            TextView t2 = findViewById(R.id.Tag2_value);
            t2.setText(Integer.toString(tag2));
            TextView t3 = findViewById(R.id.Tag3_value);
            t3.setText(Integer.toString(tag3));
            TextView t4 = findViewById(R.id.Tag4_value);
            t4.setText(Integer.toString(tag4));
            TextView t5 = findViewById(R.id.Tag5_value);
            t5.setText(Integer.toString(tag5));
            TextView t6 = findViewById(R.id.Tag6_value);
            t6.setText(Integer.toString(tag6));

            ArrayAdapter adapter  = new ArrayAdapter(this,android.R.layout.simple_list_item_1, listItems);
            mlist.setAdapter(adapter);


        } catch (IOException e) {
            mlist.setEnabled(false);
            mlist.setVisibility(View.INVISIBLE);
            msg.setVisibility(View.VISIBLE);

            rating = 0;
            RatingBar rb = findViewById(R.id.ratingBar);
            rb.setRating((float)rating);
            tag1 = 0;
            TextView t1 = findViewById(R.id.Tag1_value);
            t1.setText(Integer.toString(tag1));
            tag2 = 0;
            TextView t2 = findViewById(R.id.Tag2_value);
            t2.setText(Integer.toString(tag2));
            tag3 = 0;
            TextView t3 = findViewById(R.id.Tag3_value);
            t3.setText(Integer.toString(tag3));
        }
    }
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(final MenuItem item){
        switch (item.getItemId()){
            case R.id.menu:
                Log.d("testing", "Add button clicked");
                Intent addIntent = new Intent(this, AddActivity.class);
                startActivity(addIntent );
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
