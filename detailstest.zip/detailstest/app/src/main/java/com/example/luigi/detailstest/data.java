package com.example.luigi.detailstest;

public class data {
    public int tag1;
    public int tag2;
    public int tag3;
    public int tag4;
    public int tag5;
    public int tag6;
    public double rating;
    public String comment;
}
