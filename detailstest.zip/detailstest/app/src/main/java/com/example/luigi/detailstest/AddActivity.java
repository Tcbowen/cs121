package com.example.luigi.detailstest;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class AddActivity extends AppCompatActivity {
    String userName = "tom";
    JSONObject jo;
    JSONArray Bathrooms;
    JSONArray ja;
    int brNum = 0;
    double rating = 0;
    int t1 = 0;
    int t2 = 0;
    int t3 = 0;
    int t4 = 0;
    int t5 = 0;
    int t6 = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        final EditText comment = findViewById(R.id.addText);
        final RatingBar rb = findViewById(R.id.ratingBar2);
        final Button b = findViewById(R.id.Enter);
        final Button tag1 = findViewById(R.id.Tag1);
        final Button tag2 = findViewById(R.id.Tag2);
        final Button tag3 = findViewById(R.id.Tag3);
        final Button tag4 = findViewById(R.id.Tag4);
        final Button tag5 = findViewById(R.id.Tag5);
        final Button tag6 = findViewById(R.id.Tag6);

        try {
            File f = new File(getFilesDir(), userName + ".ser");
            FileInputStream fi = new FileInputStream(f);
            ObjectInputStream o = new ObjectInputStream(fi);
            String j = null;
            try {
                j = (String)o.readObject();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            try {
                jo = new JSONObject(j);
                Bathrooms = jo.getJSONArray("bathrooms");
            } catch (JSONException e) {
                jo = new JSONObject();
                Bathrooms = new JSONArray();
                try {
                    jo.put("bathrooms", Bathrooms);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
            }

            try {
                ja = Bathrooms.getJSONArray(brNum);
            } catch (JSONException e) {
                e.printStackTrace();
                ja = new JSONArray();
                try {
                    Bathrooms.put(brNum, ja);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                    Log.d("test", "ja Error");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        tag1.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
              if(t1 == 0){
                  t1 = 1;
                  tag1.setBackgroundColor(Color.YELLOW);
              }
              else{
                  t1 = 0;
                  tag1.setBackgroundColor(Color.GRAY);
              }
              Log.d("test","tag1: " + t1);
            }
        });
        tag2.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
                if(t2 == 0){
                    t2 = 1;
                    tag2.setBackgroundColor(Color.YELLOW);
                }
                else{
                    t2 = 0;
                    tag2.setBackgroundColor(Color.GRAY);
                }
                Log.d("test","tag1: " + t2);
            }
        });
        tag3.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
                if(t3 == 0){
                    t3 = 1;
                    tag3.setBackgroundColor(Color.YELLOW);
                }
                else{
                    t3 = 0;
                    tag3.setBackgroundColor(Color.GRAY);
                }
                Log.d("test","tag3: " + t3);
            }
        });
        tag4.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
                if(t4 == 0){
                    t4 = 1;
                    tag4.setBackgroundColor(Color.YELLOW);
                }
                else{
                    t3 = 0;
                    tag4.setBackgroundColor(Color.GRAY);
                }
                Log.d("test","tag4: " + t4);
            }
        });
        tag5.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
                if(t5 == 0){
                    t5 = 1;
                    tag5.setBackgroundColor(Color.YELLOW);
                }
                else{
                    t5 = 0;
                    tag5.setBackgroundColor(Color.GRAY);
                }
                Log.d("test","tag5: " + t5);
            }
        });
        tag6.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View view) {
                if(t6 == 0){
                    t6 = 1;
                    tag6.setBackgroundColor(Color.YELLOW);
                }
                else{
                    t6 = 0;
                    tag6.setBackgroundColor(Color.GRAY);
                }
                Log.d("test","tag6: " + t6);
            }
        });
        b.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v){

                String Comment = comment.getText().toString();
                rating = rb.getRating();
                Log.d("test", "Rating: " + rating);
                JSONObject temp =new JSONObject();

                try {
                    temp.put("comment", Comment);
                    temp.put("rating", rating);
                    temp.put("tag1", t1);
                    temp.put("tag2", t2);
                    temp.put("tag3", t3);
                    temp.put("tag4", t4);
                    temp.put("tag5", t5);
                    temp.put("tag6", t6);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ja.put(temp);

                try {
                    File f = new File(getFilesDir(), userName + ".ser");
                    FileOutputStream fo = new FileOutputStream(f);
                    ObjectOutputStream o = new ObjectOutputStream(fo);
                    String j = jo.toString();
                    o.writeObject(j);
                    o.close();
                    fo.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Intent i = new Intent(AddActivity.this, DetailActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });
    }


}

