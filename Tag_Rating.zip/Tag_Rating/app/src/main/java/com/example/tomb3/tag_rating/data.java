package com.example.tomb3.tag_rating;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class data {
   int[] tags = new int[3];
   int rating;

   public void setTag(JSONArray tag){
       for (int i = 0; i < tag.length(); i++) {
           try {
               tags[i] = tag.getInt(i);
           } catch (JSONException e) {
               e.printStackTrace();
           }
       }
   }
    public void setRating(int Rating){
       rating = Rating;
    }
   public String toString() {
       String output="";
       String[] tag_data = {"Clean", "Dirty", "Crowded"};
       for (int i = 0; i < tags.length; i++) {
           if (tags[i] == 1) {
               output += tag_data[i]+", ";
               Log.d("out", tag_data[i]);
           }
       }
       Log.d("out", output);
           return output;
   }
   public float getRating(){
       return (float) rating;
   }
}
