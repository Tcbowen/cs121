package com.example.tomb3.tag_rating;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
        String userName = "tom";
    JSONObject user = null;
    JSONArray Bathrooms = null;
    JSONObject Bathroom = null;
    JSONArray Tag = null;
     int brNum = 0;
     int numTags =3;
     TextView out;
    ArrayList<data> data_list;
    int user_input =5;
    RatingBar ratingBar;
    Button t1;
    Button t2;
    Button t3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        out = findViewById(R.id.Tag_output);
        ratingBar = findViewById(R.id.ratingBar);
        t1 = findViewById(R.id.tag_0);
        t2 = findViewById(R.id.tag_1);
        t3 = findViewById(R.id.tag_2);

    }

   public void upDate(View view) {
       data_list = new ArrayList<data>(3);
       try {
           File JD = new File(getFilesDir(), userName + ".ser");
           FileInputStream fi = new FileInputStream(JD);
           ObjectInputStream o = new ObjectInputStream(fi);
           String j = null;
           try {
               j = (String) o.readObject();
           } catch (Exception e) {
               e.printStackTrace();
           }
           user = new JSONObject(j);
           Bathrooms = user.getJSONArray("bathrooms");
       } catch (IOException e) {
           user = new JSONObject();
           Bathrooms = new JSONArray();
           try {
               user.put("bathrooms", Bathrooms);
               try {
                   File data = new File(getFilesDir(), userName + ".ser");
                   FileOutputStream fi = new FileOutputStream(data);
                   ObjectOutputStream o = new ObjectOutputStream(fi);
                   String j = user.toString();
                   o.writeObject(j);
                   o.close();
                   fi.close();
               } catch (Exception e2) {
                   e.printStackTrace();
               }
               e.printStackTrace();

           } catch (JSONException e1) {
               e1.printStackTrace();
           }
       } catch (JSONException e) {
           e.printStackTrace();
       }
       data d;
            try {
               Bathroom = Bathrooms.getJSONObject(brNum);
            } catch (JSONException e) {
                e.printStackTrace();
                Bathroom = new JSONObject();
                Tag =  new JSONArray();
                try {
                    Bathroom.put("tag",Tag );
                    Tag.put(0, 0);
                    Tag.put(1, 0);
                    Tag.put(2, 0);
                    Bathroom.put("rating",user_input);
                } catch (JSONException e1) {
                    e1.printStackTrace();
                    Log.d("test","data not set");
                }
                Bathrooms.put(Bathroom);
                Log.d("test",Bathroom.toString()+"added");
            }
                d = new data();
                try {
                    Tag = Bathroom.getJSONArray("tag");
                    int rating = Bathroom.getInt("rating");
                    d.setTag(Tag);
                    d.setRating(rating);
                    data_list.add(d);
                    Log.d("test", Tag.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("test", "not set");
                }
        String output = "";
            try {
                output += data_list.get(brNum).toString();
                output += "\n";
            }catch (Exception e){
                Log.d("test", "system Fail");
            }
        out.setText(output);
        // add start for the rating
        ratingBar.setRating((float) data_list.get(brNum).getRating());
        if (d.tags[0]==1){
            t1.setBackgroundColor(Color.YELLOW);
        }
       if (d.tags[1]==1){
           t2.setBackgroundColor(Color.YELLOW);
       } if (d.tags[2]==1){
           t3.setBackgroundColor(Color.YELLOW);
       }

   }
   public void Tag1(View view){
       try {
           if (Tag.getInt(0)==0) {
               try {
                   Tag.put(0, 1);
                   t1.setBackgroundColor(Color.YELLOW);
               } catch (JSONException e) {
                   e.printStackTrace();
               }
           }else{
               try {
                   Tag.put(0, 0);
                   t1.setBackgroundColor(Color.GRAY);
               } catch (JSONException e) {
                   e.printStackTrace();
               }
           }
       } catch (JSONException e) {
           e.printStackTrace();
       }
       write();
   }
    public void Tag2(View view){
        try {
            if (Tag.getInt(1)==0) {
                try {
                    Tag.put(1, 1);
                    t2.setBackgroundColor(Color.YELLOW);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                try {
                    Tag.put(1, 0);
                    t2.setBackgroundColor(Color.GRAY);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        write();
    }
    public void Tag3(View view){
        try {
            if (Tag.getInt(2)==0) {
                try {
                    Tag.put(2, 1);
                    t3.setBackgroundColor(Color.YELLOW);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                try {
                    Tag.put(2, 0);
                    t3.setBackgroundColor(Color.GRAY);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        write();
    }
    public void rate(View view){
        float rating = ratingBar.getRating();
        try {
            Bathroom.put("rating", rating);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        write();
    }
    private void write() {
        try {
            File data = new File(getFilesDir(), userName + ".ser");
            FileOutputStream fi = new FileOutputStream(data);
            ObjectOutputStream o = new ObjectOutputStream(fi);
            String j = user.toString();
            o.writeObject(j);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
