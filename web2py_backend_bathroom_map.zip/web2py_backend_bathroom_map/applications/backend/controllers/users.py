

def login():
    redirect(URL('default', 'user', args=['login'], vars=dict(_next='/backend/users/success')))


@auth.requires_login()
def logout():
    redirect(URL('default', 'user', args=['logout'], vars=dict(_next='/')))


@auth.requires_login()
def success():
    us = UserStorage()
    u = us.get_or_insert(auth.user.user_token, user_id=auth.user.user_token)
    # us.user_id = auth.user.user_token
    u.user_name = auth.user.first_name
    u.put()
    return dict(user_token=auth.user.user_token)


