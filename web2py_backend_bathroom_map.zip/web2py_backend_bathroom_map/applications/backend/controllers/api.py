from google.appengine.ext import ndb


@auth.requires_login()
def send_json():
    user_id = request.vars.id
    content = request.vars.content
    # Now I have to insert the message.
    us = UserStorage.query()
    us = us.filter(UserStorage.user_id == user_id)
    u = us.get()
    # us = user_id.get()
    u.user_content = content
    u.put()
    return response.json("ok")


@auth.requires_login()
def get_user_json():
    user_id = request.vars.id
    # us = user_id.get()
    # us = UserStorage.get(user_id=user_id)
    us = UserStorage.query()
    us = us.filter(UserStorage.user_id == user_id)
    u = us.get()
    res = dict(name=u.user_name,
               json_content=u.user_content,
               )
    return response.json(res)


def get_json_dump():
    q = UserStorage.query()
    res = []
    # Now let's read the data.
    for r in q.iter():
        res.append(dict(
           name=r.user_name,
           content=r.user_content,
        ))
    return response.json(dict(results=res))