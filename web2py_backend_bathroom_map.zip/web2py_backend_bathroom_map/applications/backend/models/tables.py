from google.appengine.ext import ndb


class BathroomNode(ndb.Model):
    node_id = ndb.StringProperty()
    # gps_lat = ndb.FloatProperty()
    # gps_long = ndb.FloatProperty()
    rating = ndb.IntegerProperty()
    comments = ndb.JsonProperty()


class UserStorage(ndb.Model):
    user_id = ndb.StringProperty()
    user_name = ndb.StringProperty()
    user_content = ndb.JsonProperty()
    bathrooms = ndb.StructuredProperty(BathroomNode, repeated=True)


class BackendStorage(ndb.Model):
    sender = ndb.StringProperty()
    recipient = ndb.StringProperty()
    msg = ndb.TextProperty()
    msg_date = ndb.DateTimeProperty(auto_now_add=True)
    was_read = ndb.BooleanProperty(default=False)
    lat = ndb.FloatProperty(indexed=False)
    lng = ndb.FloatProperty(indexed=False)
    latlng = ndb.StringProperty()
    version = ndb.IntegerProperty()



