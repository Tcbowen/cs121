jQuery(document).ready(function(){jQuery('[multiple]').multiSelect({selectableHeader:'<b>Options</b>',selectedHeader:'<b>Selected</b>'});});
