#!/usr/bin/env python
{
# "singular form (0)": ["first plural form (1)", "second plural form (2)", ...],
'файл': ['файла','файлов'],
}
